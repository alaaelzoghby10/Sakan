﻿
using myfirstrentsell.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Helpers;
using System.Web.Mvc;

namespace myfirstrentsell.Controllers
{
    public class homeController : Controller
    {
        ProductsEntities5 nh = new ProductsEntities5();

        // 1-Done
        #region Add a new home


        [HttpGet]
        public ActionResult add()
        {
            if (Session["userid"] == null)
            {
                return RedirectToAction("login", "user");
            }

            if (Session["confirmed"] == null)
            {
                return RedirectToAction("confirmmail", "user");
            }
            @ViewBag.city_id = new SelectList(nh.cities, "city_name", "city_name");
            @ViewBag.country_id = new SelectList(nh.countries, "country_name", "country_name");
            return View();
        }

        [HttpPost]
        public ActionResult add(product_information product)
        {

            string imagename = "";
            string imagepath = "";
            string videoname = "";
            string videopath = "";
            string multipleimagename = "";
            string multipleimagepath = "";
            string allmultipleimagepath = "";

            HttpPostedFileBase file = product.imagelink;
            if (file.ContentLength > 0)
            {
                imagename = Path.GetFileName(file.FileName);
                imagepath = Path.Combine(Server.MapPath("~/uploads/homes/large" + imagename));
                file.SaveAs(imagepath);
            }

            HttpPostedFileBase filevideo = product.videolink;
            if (filevideo.ContentLength > 0)
            {
                videoname = Path.GetFileName(filevideo.FileName);
                videopath = Path.Combine(Server.MapPath("~/uploads/homes/"+videoname));
                file.SaveAs(videopath);
            }

            string imagepathsmall = Path.Combine(Server.MapPath("~/uploads/homes/" + imagename));

            allmultipleimagepath = imagename;
            //multiple images

            foreach (HttpPostedFileBase item in product.images)
            {
                if (item != null)
                {
                    multipleimagename = Path.GetFileName(item.FileName);
                    allmultipleimagepath += "," + multipleimagename;
                    multipleimagepath = Path.Combine(Server.MapPath("~/uploads/homes/" + multipleimagename));
                    item.SaveAs(multipleimagepath);
                }
            }


            //resize image
            //WebImage img = new WebImage(file.InputStream);
            //if (img.Width > 440)
            //{
            //    img.Resize(440, 330);
            //}

            //else if(img.Height>330)
            //{
            //    img.Resize(440, 330);
            //}
            //img.Save(imagepathsmall);


            ThumbNail.CreateThumbnail(imagepath, imagepathsmall, 340, 255);
            System.IO.File.Delete(imagepath);


            product.type = product.mytype.ToString();
            product.date = DateTime.Now;
            product.numberofviews = 0;
            product.image1 = allmultipleimagepath;
            product.video = videoname;
            int userid = Convert.ToInt32(Session["userid"]);
            product.owner_id = userid;
            nh.product_information.Add(product);
            nh.Configuration.ValidateOnSaveEnabled = false;
            try
            {
                nh.SaveChanges();
            }

            catch (System.Data.Entity.Validation.DbEntityValidationException dbex)
            {
                Exception raise = dbex;
                foreach (var validationerrors in dbex.EntityValidationErrors)
                {
                    foreach (var validationerror in validationerrors.ValidationErrors)
                    {
                        string msg = string.Format("{0}:{1}",
                            validationerrors.Entry.Entity.ToString(),
                            validationerror.ErrorMessage);
                        raise = new InvalidOperationException(msg, raise);
                    }
                }
                throw raise;
            }


            return RedirectToAction("manage", "home");
        }


        #endregion


        // 2-Done
        #region Manage rooms

        public ActionResult manage()
        {
            int userId = Convert.ToInt32(Session["userid"]);
            if (Session["userid"] == null)
            {
                return RedirectToAction("login", "user");
            }

            if (Session["confirmed"] == null)
            {
                return RedirectToAction("confirmmail", "user");
            }

            var homes = from b in nh.product_information where b.owner_id == userId select b;
            var myhomes = homes.OrderByDescending(m=>m.date);

            return View(myhomes);
        }

        #endregion


        // 3-Done
        #region Delete

        public ActionResult delete(int failed1, int failed2)
        {
            int userId = Convert.ToInt32(Session["userid"]);
            if (Session["userid"] == null)
            {
                return RedirectToAction("login", "user");
            }

            if (Session["confirmed"] == null)
            {
                return RedirectToAction("confirmmail", "user");
            }

            if (failed2 != userId)
            {
                return RedirectToAction("profile", "user");
            }

            product_information myhome = nh.product_information.First(m => m.id == failed1);

            string nametodelete = myhome.image1.Substring(0, myhome.image1.IndexOf(','));

            System.IO.File.Delete(Server.MapPath("~/uploads/homes/" + nametodelete));
            System.IO.File.Delete(Server.MapPath("~/uploads/homes/" + myhome.video));

            string image = "";
            List<string> myimages = new List<string>();
            string imagetoadd;
            int start = myhome.image1.IndexOf(',') + 1;
            string img = myhome.image1.Substring(start, myhome.image1.Length - start) + ",";
            foreach (char item in img)
            {
                if (item == ',')
                {
                    imagetoadd = image;
                    image = "";
                    System.IO.File.Delete(Server.MapPath("~/uploads/homes/images/" + imagetoadd));
                    continue;
                }
                image += item;
            }

            nh.product_information.Remove(myhome);
            nh.SaveChanges();
            return RedirectToAction("manage");

        }

        #endregion



        // 4-done
        #region Update room

        //update rooms
        [HttpGet]
        public ActionResult update(int failed1, int failed2)
        {
            int userId = Convert.ToInt32(Session["userid"]);
            if (Session["userid"] == null)
            {
                return RedirectToAction("login", "user");
            }

            if (Session["confirmed"] == null)
            {
                return RedirectToAction("confirmmail", "user");
            }

            if (failed2 != userId)
            {
                return RedirectToAction("profile", "user");
            }


            @ViewBag.city_id = new SelectList(nh.cities, "city_name", "city_name");
            @ViewBag.country_id = new SelectList(nh.countries, "country_name", "country_name");
            var currentHome = nh.product_information.First(m => m.id == failed1);

            return View(currentHome);
        }

        [HttpPost]
        public ActionResult update(product_information product)
        {

            string imagename = "";
            string imagepath = "";
            string videoname = "";
            string videopath = "";
            string multipleimagename = "";
            string multipleimagepath = "";
            string allmultipleimagepath = "";

            HttpPostedFileBase file = product.imagelink;
            if (file.ContentLength > 0)
            {
                imagename = Path.GetFileName(file.FileName);
                imagepath = Path.Combine(Server.MapPath("~/uploads/homes/large" + imagename));
                file.SaveAs(imagepath);
            }

            HttpPostedFileBase filevideo = product.videolink;
            if (filevideo.ContentLength > 0)
            {
                videoname = Path.GetFileName(filevideo.FileName);
                videopath = Path.Combine(Server.MapPath("~/uploads/homes/"+videoname));
                file.SaveAs(videopath);
            }

            string imagepathsmall = Path.Combine(Server.MapPath("~/uploads/homes/" + imagename));

            allmultipleimagepath = imagename;
            //multiple images

            foreach (HttpPostedFileBase item in product.images)
            {
                if (item != null)
                {
                    multipleimagename = Path.GetFileName(item.FileName);
                    allmultipleimagepath += "," + multipleimagename;
                    multipleimagepath = Path.Combine(Server.MapPath("~/uploads/homes/images/" + multipleimagename));
                    item.SaveAs(multipleimagepath);
                }
            }


            //resize image
            WebImage img = new WebImage(file.InputStream);
            img.Resize(440, 275);
            img.Save(imagepathsmall);


            product_information p = nh.product_information.First(m => m.id == product.id);
            product.type = product.mytype.ToString();
            p.id = product.id;
            p.title = product.title;
            p.price = product.price;
            p.details = product.details;
            p.country = product.country;
            p.city = product.city;
            p.width = product.width;
            p.type = product.type;
            p.video = videoname;
            p.image1 = allmultipleimagepath;
            product.type = product.mytype.ToString();
            nh.Configuration.ValidateOnSaveEnabled = false;


            //product.date = DateTime.Now;
            //product.numberofviews = 0;
            //product.image1 = allmultipleimagepath;
            //product.video = videoname;
            //int userid = Convert.ToInt32(Session["userid"]);
            //product.owner_id = userid;

            //nh.Entry(p).State = EntityState.Modified;
            //nh.Entry(product).CurrentValues.SetValues(p);

            try
            {
                nh.SaveChanges();
            }

            catch (System.Data.Entity.Validation.DbEntityValidationException dbex)
            {
                Exception raise = dbex;
                foreach (var validationerrors in dbex.EntityValidationErrors)
                {
                    foreach (var validationerror in validationerrors.ValidationErrors)
                    {
                        string msg = string.Format("{0}:{1}",
                            validationerrors.Entry.Entity.ToString(),
                            validationerror.ErrorMessage);
                        raise = new InvalidOperationException(msg, raise);
                    }
                }
                throw raise;
            }


            return RedirectToAction("manage");
        }

        #endregion


        //Done  
        #region Details

        public ActionResult details(int id)
        {
            var searchedHome = nh.product_information.First(m => m.id == id);

            searchedHome.numberofviews = searchedHome.numberofviews + 1;
            nh.Configuration.ValidateOnSaveEnabled = false;
            nh.SaveChanges();
            return View(searchedHome);
        }

        #endregion


        //Done
        #region index
        public ActionResult index(string id)
        {
            
            if (id == null)
            {
                var homes = nh.product_information.OrderBy(m => m.date).ThenBy(m => m.numberofviews);
                var myhomes = homes.OrderByDescending(m=>m.date).Take(18);
                return View(myhomes);
            }

            else
            {
                var homes = from b in nh.product_information
                            where b.type == id
                            select b;
                var myhomes = homes.OrderByDescending(m => m.date);
                return View(myhomes);
            }

        }


        #endregion


    }
        
        //still dropdown based on another
        //home slider
       

    }

