﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using myfirstrentsell.Models;
using System.IO;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Data.Entity;
using System.Web.Helpers;
using System.Configuration;

namespace myfirstrentsell.Controllers
{
    public class userController : Controller
    {
        ProductsEntities5 nh = new ProductsEntities5();



        //1-done
        #region register
        [HttpGet]
        public ActionResult register()
        {
            if(Session["user"]==null)
            {
            return View();
            }

            else
            {
                return RedirectToAction("profile");
            }
        }

        [HttpPost]
        public ActionResult register(owner_information user)
        {
            string filename = "";
            string path = "";
            if (ModelState.IsValid)
            {
                try
                {
                    var checkForUserNameValidity = nh.owner_information.First(m => m.mail == user.mail);
                    ViewBag.message = "Email exists please choose a nother one";
                    return View(user);
                }

                catch
                {
                    HttpPostedFileBase file = user.imagelink;
                    if (file.ContentLength > 0)
                    {
                        filename = Path.GetFileName(file.FileName);
                        path = Path.Combine(Server.MapPath("~/uploads/profile/s"+filename));
                        file.SaveAs(path);
                    }


                    //string largeimg = Server.MapPath("~/uploads/" +filename);

                    //ThumbNail.CreateThumbnail(largeimg, "l" + filename, 265, 327);
                    user.image = filename;
                    user.gender = user.yourgender.ToString();
                    //System.IO.File.Delete(path);

                    //resize image
                    string imagepathsmall = Path.Combine(Server.MapPath("~/uploads/profile/" + filename));
                    ThumbNail.CreateThumbnail(path,imagepathsmall, 265, 327);
                    System.IO.File.Delete(path);
                    //WebImage img = new WebImage(file.InputStream);
                    //img.Resize(265, 327);
                    //img.Save(imagepathsmall);


                    user.mailConfirmed = false;
                    user.isadmin = false;
                    nh.owner_information.Add(user);
                    nh.Configuration.ValidateOnSaveEnabled = false;
                    nh.SaveChanges();


                    string code = (user.id * 25 + 100).ToString();
                    Session["confirmCode"] = code;
                    Session["userid"] = user.id;
                    Session["name"] = user.name;

                    Mail.SendMail("SAKAN account configuration message", user.mail, "configuration code is: " + code, false);

                    return RedirectToAction("confirmMail");

                }

                }
            return View(user);
        }
        #endregion


        //2-done
        #region Confirm Mail
        
        
        [HttpGet]
       public ActionResult confirmmail()
        {
            if (Session["user"]==null)
            {
                return RedirectToAction("login");
            }
            return View();
        }

        [HttpPost]
        public ActionResult confirmmail(string confirmpassword)
        {

            int code = (Convert.ToInt32(Session["userid"])) * 25 + 100;
            if ( confirmpassword==code.ToString())
            {
                int userId = Convert.ToInt32(Session["userid"]);
                var currentUser = nh.owner_information.First(m => m.id == userId);
                currentUser.mailConfirmed = true;
                nh.Configuration.ValidateOnSaveEnabled = false;
               
                Session["confirmed"] = "confirmed";

                nh.SaveChanges();

               return RedirectToAction("profile");
            
             }
                
                
            ViewBag.message = "Activation code is incorrect";
            return View();
        }

        #endregion

        //3-done
        #region logIn

        [HttpGet]
        public ActionResult login()
        {
           
            if (Session["userid"] ==null)
            {
                return View();
            }

            else
            {
                return RedirectToAction("profile", "user");
            }
        }

        
        [HttpPost]
        public ActionResult login(string name, string password)
        {

            try
            {
                var user = nh.owner_information.First(m => (m.mail == name) && (m.password == password));
                TempData["confirmCode"] = user.id * 25 + 100;
                Session["userid"] = user.id.ToString();
                Session["user"] = user.name;
                if (user.mailConfirmed != true)
                {

                    return RedirectToAction("confirmmail");
                }
                else
                {
                    Session["confirmed"] = "confirmed";   
                    return RedirectToAction("profile");
                }
            }
            catch
            {

                ViewBag.message = "Mail or Password is incorrect";
                return View();
            }



        }

        #endregion

        //4-done
        #region Reset

        [HttpGet]
        public ActionResult reset()
        {
            return View();
        }

        [HttpPost]
        public ActionResult reset(string mail)
        {
            var user=new owner_information();
            try
            {
                user = nh.owner_information.First(m => m.mail == mail);
            }

            catch
            {
             ViewBag.message = "Mail don't exist register a new account";
             return View();
            }

            Mail.SendMail("Reset your account message", user.mail, "User name: " + user.name + "\n Password: " + user.password, false);
            return RedirectToAction("login");
           
        }

        #endregion

        
        //5-done
        #region profile

        public ActionResult profile()
        {
            //int id = Convert.ToInt32(TempData["id"]);
            //if (id==0)
            if (Session["userid"]==null)
            
            {
                return RedirectToAction("login");
            }


            //string userName=TempData["username"].ToString();
            int userid = Convert.ToInt32(Session["userid"]);

            var currentUser = nh.owner_information.First(m => m.id == userid);
            if(Session["confirmed"]==null)
            {
                RedirectToAction("confirmmail");
            }
            return View(currentUser);
        }

        #endregion
        
        //6-done
        #region Show owner information
         public ActionResult showOwnerInformation(int id)
        {
            var ownerinfo = nh.owner_information.First(m => m.id == id);
            return View(ownerinfo);
        }
        #endregion


        // 7-done
         #region Update user information
          [HttpGet]
        public ActionResult update(int id)
         {
              int userid=Convert.ToInt32(Session["userid"]);
              if(Session["userid"]==null)
              {
                  return RedirectToAction("login");
              }
             if (userid!=id)
             {
                 return RedirectToAction("profile");
             }

             var user = nh.owner_information.First(m => m.id == id);
             return View(user);
         }
        

        [HttpPost]
        public ActionResult update(owner_information owner)
        {
            int userid = Convert.ToInt32(Session["userid"]);
            owner.confirmmail = owner.mail;
             string filename = "";
            string path = "";
            
                HttpPostedFileBase file = owner.imagelink;
                if (file.ContentLength > 0)
                {
                    filename = Path.GetFileName(file.FileName);
                    path = Path.Combine(Server.MapPath("~/uploads/profile"), filename);
                    file.SaveAs(path);
                }

                var updatedUser = nh.owner_information.First(m => m.id == userid);
                System.IO.File.Delete(Server.MapPath("~/uploads/profile/" + updatedUser.image));
                updatedUser.name = owner.name;
                updatedUser.phone = owner.phone;
                updatedUser.name = owner.name;
                updatedUser.address = owner.address;
                updatedUser.dateofbirth = owner.dateofbirth;
                updatedUser.password = owner.password;
                updatedUser.fname = owner.fname;
                updatedUser.lname = owner.lname;
                updatedUser.gender = owner.yourgender.ToString();
                updatedUser.image = filename;
                nh.Configuration.ValidateOnSaveEnabled = false;


                //nh.Entry(updatedUser).State = EntityState.Modified;
                //nh.Entry(updatedUser).CurrentValues.SetValues(owner);
                try
                {
                    nh.SaveChanges();
                }

                catch (System.Data.Entity.Validation.DbEntityValidationException dbex)
                {
                    Exception raise = dbex;
                    foreach (var validationerrors in dbex.EntityValidationErrors)
                    {
                        foreach (var validationerror in validationerrors.ValidationErrors)
                        {
                            string msg = string.Format("{0}:{1}",
                                validationerrors.Entry.Entity.ToString(),
                                validationerror.ErrorMessage);
                            raise = new InvalidOperationException(msg, raise);
                        }
                    }
                    throw raise;
                
            }
               Session["user"] = owner.name;

                return RedirectToAction("profile");

            
        }
         #endregion


        // 8-done
        #region Log Out
         public ActionResult logout()
        {
            Session["userid"] = null;
            Session["user"] =  null;
            Session["confirmed"] = null;
            return RedirectToAction("login");
        }

        #endregion


         #region About
         public ActionResult about()
         {
             return View();
         }
        
         #endregion

    }
}
