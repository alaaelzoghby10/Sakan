using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Drawing;
using System.Drawing.Imaging;

/// <summary>
/// Summary description for ThumbNail
/// </summary>
public class ThumbNail
{
	public ThumbNail()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    //-----------------------------------------------------------------------------------------
    public static void CreateThumbnail(string FilenameSrc, string Filename, int imgWidth, int imgHeight)
    {
        System.Drawing.Bitmap bmpOut = null;
        Bitmap BMP = new Bitmap(FilenameSrc);
        ImageFormat Format = BMP.RawFormat;
        //HttpContext.Current.Response.ContentType = "image/jpeg";
        decimal Ratio;
        int NewWidth = 0;
        int NewHeight = 0;

        if (BMP.Width < imgWidth && BMP.Height < imgHeight)
        {
            BMP.Save(Filename);
        }
        else if (BMP.Width > imgWidth)
        {
            Ratio = (decimal)imgWidth / BMP.Width;
            Decimal tempNewWidth = Ratio * BMP.Width;
            Decimal tempNewHeight = Ratio * BMP.Height;
            NewHeight = (int)tempNewHeight;
            NewWidth = (int)tempNewWidth;
        }
        else if (BMP.Width > imgWidth)
        {
            Ratio = (decimal)imgHeight / BMP.Height;
            Decimal tempNewWidth = Ratio * BMP.Width;
            Decimal tempNewHeight = Ratio * BMP.Height;
            NewHeight = (int)tempNewHeight;
            NewWidth = (int)tempNewWidth;
        }
        else
        {
            NewHeight = imgHeight;
            NewWidth = imgWidth;
        }
        bmpOut = new Bitmap(NewWidth, NewHeight);
        Graphics g = Graphics.FromImage(bmpOut);
        g.DrawImage(BMP, 0, 0, NewWidth, NewHeight);       
        bmpOut.Save(Filename);
        BMP.Dispose();
        bmpOut.Dispose();
    }
}
